package com.example.demo.controller;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.service.OpenAIService;
import com.example.demo.service.TwilioService;

@RestController
@RequestMapping("/webhook")
public class TwilioOpenAIController {
    private final TwilioService twilioService;
    private final OpenAIService openAIService;

    public TwilioOpenAIController(TwilioService twilioService, OpenAIService openAIService) {
        this.twilioService = twilioService;
        this.openAIService = openAIService;
    }

    @PostMapping("/sms")
    public ResponseEntity<String> receiveSms(@RequestParam("From") String from,
                                             @RequestParam("Body") String body) {
        String aiResponse = openAIService.getChatResponse(body);
        twilioService.sendSms(from, aiResponse);

        return ResponseEntity.ok("Message processed and response sent!");
    }
}
