package com.example.demo.service;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class OpenAIService {
    @Value("${openai.api.key}")
    private String apiKey;

    public String getChatResponse(String prompt) {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(apiKey);

        String requestBody = String.format("""
            {
                "model": "text-davinci-003",
                "prompt": "%s",
                "max_tokens": 150
            }
        """, prompt);

        HttpEntity<String> request = new HttpEntity<>(requestBody, headers);
        ResponseEntity<String> response = restTemplate.postForEntity(
            "https://api.openai.com/v1/completions",
            request,
            String.class
        );

        JsonObject jsonResponse = JsonParser.parseString(response.getBody()).getAsJsonObject();
        return jsonResponse.getAsJsonArray("choices").get(0).getAsJsonObject().get("text").getAsString();
    }
}

